import java.time.LocalDate;
import java.time.YearMonth;
import java.util.Scanner;

public class ExpenseTrackerApp {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        TransactionManager manager = new TransactionManager();

        while (true) {
            System.out.println("1. Add Income");
            System.out.println("2. Add Expense");
            System.out.println("3. Load from file");
            System.out.println("4. Save to file");
            System.out.println("5. View Monthly Summary");
            System.out.println("6. Exit");

            int choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1:
                case 2:
                    System.out.println("Enter date (YYYY-MM-DD): ");
                    LocalDate date = LocalDate.parse(scanner.nextLine());
                    String type = (choice == 1) ? "income" : "expense";

                    System.out.println("Enter category (e.g., Salary, Business, Food, Rent, Travel): ");
                    String category = scanner.nextLine();

                    System.out.println("Enter amount: ");
                    double amount = Double.parseDouble(scanner.nextLine());

                    manager.addTransaction(new Transaction(date, type, category, amount));
                    break;
                case 3:
                    System.out.println("Enter filename to load from: ");
                    String loadFile = scanner.nextLine();
                    manager.loadFromFile(loadFile);
                    break;
                case 4:
                    System.out.println("Enter filename to save to: ");
                    String saveFile = scanner.nextLine();
                    manager.saveToFile(saveFile);
                    break;
                case 5:
                    System.out.println("Enter year and month (YYYY-MM): ");
                    YearMonth month = YearMonth.parse(scanner.nextLine());
                    manager.printMonthlySummary(month);
                    break;
                case 6:
                    System.out.println("Goodbye!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}
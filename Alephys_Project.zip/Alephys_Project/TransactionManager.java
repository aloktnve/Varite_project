import java.io.*;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;

public class TransactionManager {
    private List<Transaction> transactions = new ArrayList<>();

    public void addTransaction(Transaction t) {
        transactions.add(t);
    }

    public void loadFromFile(String filename) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;
        while ((line = reader.readLine()) != null) {
            transactions.add(Transaction.fromString(line));
        }
        reader.close();
    }

    public void saveToFile(String filename) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
        for (Transaction t : transactions) {
            writer.write(t.toString());
            writer.newLine();
        }
        writer.close();
    }

    public void printMonthlySummary(YearMonth month) {
        double income = 0;
        double expense = 0;
        Map<String, Double> categoryMap = new HashMap<>();

        for (Transaction t : transactions) {
            if (YearMonth.from(t.getDate()).equals(month)) {
                if (t.getType().equalsIgnoreCase("income")) {
                    income += t.getAmount();
                } else {
                    expense += t.getAmount();
                }
                categoryMap.put(t.getCategory(),
                        categoryMap.getOrDefault(t.getCategory(), 0.0) + t.getAmount());
            }
        }

        System.out.println("Summary for " + month);
        System.out.println("Total Income: " + income);
        System.out.println("Total Expense: " + expense);
        System.out.println("By Category:");
        categoryMap.forEach((k, v) -> System.out.println("  " + k + ": " + v));
    }
}
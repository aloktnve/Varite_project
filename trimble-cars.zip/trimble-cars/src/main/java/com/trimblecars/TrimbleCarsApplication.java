package com.trimblecars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrimbleCarsApplication {
    public static void main(String[] args) {
        SpringApplication.run(TrimbleCarsApplication.class, args);
    }
}
